@import "vendor/_vendor.js";
@import "/galgje.js";